#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	int opcao = 0;
	int soma = 0;
	int i = 0, j = 0;
	/*declara��o vetor idades*/
	int vetoridades[5];
	
	do {
		printf("\n");
		printf(":: MANIPULACAO VETOR::.. \n");
		printf("1. Inicializar vetor     \n");
		printf("2. Carregar              \n");
		printf("3. Imprimir              \n");
		printf("4. Somar                 \n");
		printf("9. Sair                  \n");
		printf("Digite a opcao: ");
		scanf("%i", &opcao);
		
		if (opcao == 1) {
			for (i = 0; i < 5; i++) {
				vetoridades[i] = 0;
			}
			printf("Vetor inicializado! \n");
		
		} else if (opcao == 2) {
			for (i = 0; i < 5; i++) {
				printf("Digite um valor para posicao %i: \n", i);
				scanf("%i", &j);
				
				vetoridades[i] = j;
			}
			
		} else if (opcao == 3) {
			for (i = 0; i < 5; i++) {
				printf("Valor da posicao [%i]: %i \n", i, vetoridades[i]);
			}
			
		} else if (opcao == 4) {
			j = 0;
			
			for (i = 0; i < 5; i++) {
				j = j + vetoridades[i];
			}
			printf("A soma das idades e: %i \n", j);
			
		}
		
	} while (opcao != 9);
	
	system("pause");
	return 0;
}

