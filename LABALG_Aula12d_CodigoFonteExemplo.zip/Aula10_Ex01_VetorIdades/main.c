#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	/*declara��o vetor*/
	int vetorIdades[5];
	
	/*carregamento vetor (entrada)*/
	vetorIdades[0] = 5;
	vetorIdades[1] = 2;
	vetorIdades[2] = 13;
	vetorIdades[3] = 8;
	vetorIdades[4] = 6;
	
	/*soma das idades (processamento)*/
	int soma = 0;
	soma = soma + vetorIdades[0];
	soma = soma + vetorIdades[1];
	soma = soma + vetorIdades[2];
	soma = soma + vetorIdades[3];
	soma = soma + vetorIdades[4];
	
	/* outras op��es de soma
	soma = vetorIdades[0] + vetorIdades[1] + vetorIdades[2] + vetorIdades[3] + vetorIdades[4];  

	ou 

	printf("A soma das idade e: %i \n", vetorIdades[0] + 
	                                    vetorIdades[1] + 
										vetorIdades[2] + 
										vetorIdades[3] + 
										vetorIdades[4]);
	 */
	
	/*impress�o da soma das idades (saida)*/
	printf("A soma das idade e: %i \n", soma);
	
	system("pause");
	return 0;
}
