#include <stdio.h>
#include <stdlib.h>

/* Mar�al, J. 
 * Solicitar 5 valores inteiros, multiplicar por 3
 * e apresentar o resultado da multiplica��o.
 */

int main(int argc, char *argv[]) {
	int i = 1;
	int x, r = 0;
	
	for (i = 1; i <= 5; i++) {
		printf("\n");
		printf("Digite um valor inteiro: ");
		scanf("%i", &x);
		
		r = x * 3;
		printf("O valor %i * 3 e: %i. \n", x, r);		
	}
	
	return 0;
}




