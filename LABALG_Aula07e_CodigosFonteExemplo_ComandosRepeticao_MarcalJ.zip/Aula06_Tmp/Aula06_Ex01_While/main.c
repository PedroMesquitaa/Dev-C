#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
	int cont = 0;
	float n1, n2, m = 0.0;
	int i = 0;

	printf(" Inicio %i \n ", cont);

	for (cont = 1; cont <= 5; cont = cont + 1) {
		printf("\n");
		printf("Digite a nota 1:\n");
		scanf("%f", &n1);
		printf("Digite a nota 2:\n");
		scanf("%f", &n2);
		
		m = (n1 + n2) / 2;
		
		printf("Sua media e: %f \n", m);
		
		if (m < 5) {
			printf("Nao foi desta vez! \n");
		} else {
			printf("Parab�ns, voce conseguiu! \n");
		}
		
		printf("cont = %i \n", cont);
		
	}
	
	printf("Fim %i \n", cont);
	
	return 0;		
}
