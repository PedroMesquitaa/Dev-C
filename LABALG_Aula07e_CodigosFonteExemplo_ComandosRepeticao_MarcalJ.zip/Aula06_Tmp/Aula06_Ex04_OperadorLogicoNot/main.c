#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	int x = 0;
	
	scanf("%i", &x);
	
	if (!(x>3)) {
		printf("valor");	
	};
		
	return 0;
}
