#include <stdio.h>
#include <stdlib.h>

/*
	Crie um programa para calcular a media escolar
	dos alunos da turma, a m�dia � calculada da 
	seguinte manteira
	m = (av1 * 30%) + (av2 * 40%) + (tr * 30%)
	se m >= 6.0 aprovado, caso contr�rio reprovado. 
	
	O programa deve calcular a m�dia para N alunos.

*/

int main(int argc, char *argv[]) {
	float av1, av2, tr, m = 0.0;
	int controle = 8899;

	do {
		scanf("%f", &av1);
		scanf("%f", &av2);
		scanf("%f", &tr);
	
		m = (av1 * 0.3)	+ (av2 * 0.4) + (tr * 0.3);
	
		if (m >= 6.0) {
			printf("Aprovado! \n");
		} else {
			printf("Reprovado! \n");
		}
		
		printf("Deseja continuar (1 = Sim, 2 = Nao)?\n");
		scanf("%i", &controle);
		
	} while (controle == 1);

	/*	
	while (controle == 1) {
		scanf("%f", &av1);
		scanf("%f", &av2);
		scanf("%f", &tr);
	
		m = (av1 * 0.3)	+ (av2 * 0.4) + (tr * 0.3);
	
		if (m >= 6.0) {
			printf("Aprovado! \n");
		} else {
			printf("Reprovado! \n");
		}
		
		printf("Deseja continuar (1 = Sim, 2 = Nao)?\n");
		scanf("%i", &controle);
	}
	*/
	
	return 0;
}
