#include <stdio.h>
#include <stdlib.h>

/*
	Imprimir todos os valores PARES de um INTERVALO
	de valores fornecido pelo USU�RIO.
	
	Conte o numero de pares impressos. (contador)
	Some os valores pares.             (acumulador)
*/


int main(int argc, char *argv[]) {
	int vInicial, vFinal, vControle, resto = 0;
	int cont = 0, acum = 0;
	
	scanf("%i", &vInicial); 
	scanf("%i", &vFinal);   
	
	vControle = vInicial; 
	
	do {
		resto = (vControle % 2);
		
		if (resto == 0) {
			printf("%i \n", vControle);
			
			cont = cont + 1; //cont++; cont += 1; (conceito de contador)
			acum = acum + vControle; // (conceito de acumulador)			
		}

		vControle = vControle + 1;
				
	} while (vControle <= vFinal);
	
	printf("Contador: %i \n", cont);
	printf("Acumulador: %i", acum);
	
	return 0;
}
