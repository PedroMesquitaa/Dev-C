#include <stdio.h>
#include <stdlib.h>

#include <time.h>

int main(int argc, char *argv[]) {
	int opcao = 0;
	int lin = 0, col = 0, val = 0;
	/* declaracao da matriz */
	int matrizvetoridades[4][5];
	
	do {
		printf("\n");
		printf(":: MANIPULACAO MATRIZ::..\n");
		printf("1. Inicializar           \n");
		printf("2. Carregar (usuario)    \n");
		printf("3. Carregar (aleatorio)  \n");
		printf("4. Imprimir              \n");
		printf("5. Somar                 \n");
		printf("6. Contar repeticoes     \n");
		printf("9. Sair                  \n");
		printf("Digite a opcao: ");
		scanf("%i", &opcao);
		
		if (opcao == 1) {
			for (lin = 0; lin < 4; lin++) {
				for (col = 0; col < 5; col++) {
					matrizvetoridades[lin][col]	= -1;
				}
			}
			printf("Matriz inicializada (com valor -1)! \n");
		
		} else if (opcao == 2) {
			for (lin = 0; lin < 4; lin++) {
				for (col = 0; col < 5; col++) {
					printf("Digite um valor para posicao [%i, %i]: \n", lin, col);
					scanf("%i", &val);
				
					matrizvetoridades[lin][col]	= val;
				}
			}

		} else if (opcao == 3) {		
			srand(time (NULL));
			
			for (lin = 0; lin < 4; lin++) {
				for (col = 0; col < 5; col++) {
					val = 1 + (rand() % 100);
					matrizvetoridades[lin][col]	= val;
					
					printf("[%i, %i] = %i: \n", lin, col, val);
				}
			}
			
		} else if (opcao == 4) {
			printf("Impressao valores matriz: \n");
			for (lin = 0; lin < 4; lin++) {
				for (col = 0; col < 5; col++) {
					val = matrizvetoridades[lin][col];
					
					printf("[%i, %i] = %i \n", lin, col, val);
				}
			}

		} else if (opcao == 5) {
			int soma = 0;
						
			for (lin = 0; lin < 4; lin++) {
				for (col = 0; col < 5; col++) {
					soma = soma + matrizvetoridades[lin][col];
				}
			}
			printf("A soma dos valores e: %i \n", soma);
			
		} else if (opcao == 6) {
			int cont = 0;
			
			printf("Digite o valor que deveseja verificar o numero de ocorrencias: \n");
			scanf("%i", &val);
			
			for (lin = 0; lin < 4; lin++) {
				for (col = 0; col < 5; col++) {
					if(matrizvetoridades[lin][col] == val) {
						cont = cont + 1;			
					}
				}
			}
			printf("Foram encontras %i repeticoes do valor %i no vetor. \n", val, cont);

		}
		
	} while (opcao != 9);
	
	system("pause");
	return 0;
}


